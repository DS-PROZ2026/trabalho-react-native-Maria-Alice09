import React, { useState } from 'react';
import {View, ScrollView, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image} from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Quem conheceu a elena primeiro?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQS2MduZhtmTC3UJXfdU4bCa1VCeY6i6fLxkA&s',
    opcoes: ['Stefan ', 'Damon', 'klaus', 'Elijah'],
    respostaCerta: 1
  },
  {
    id: 2,
    pergunta: 'Quem é a dopplerganger de Katherine Pierce?',
    imagem: 'https://static.wikia.nocookie.net/legaciesbr/images/a/a4/Katherine01.png/revision/latest?cb=20200106002749&path-prefix=pt-br',
    opcoes: ['Caroline Forbes', 'Bonnie Bennett', 'Elena Gilbert', 'Rebekah Mikaelson'],
    respostaCerta: 2
  },
  {
    id: 3,
    pergunta: 'Qual cidade fictícia é o cenário principal da série?',
    imagem: 'https://static.wikia.nocookie.net/vampire-diaries/images/8/8a/Mfimagem.jpg/revision/latest?cb=20111129234306&path-prefix=pt-br',
    opcoes: ['Mystic Falls', 'Forks', 'Sunnydale', 'New Orleans'],
    respostaCerta: 0
  },
  {
    id: 4,
    pergunta: 'Qual é a profissão de Alaric Saltzman quando chega à cidade?',
    opcoes: ['Médico', 'Professor de história', 'Xerife', 'Bibliotecário'],
    imagem: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh1lKJfWLXpGIwRV5kWHU2D2PIThR_g0hlMkSDVmb13CYoDLexpK7RifnZ4KZ5ggc2TepOk_C4YFfDNIk_GC-ynpYOkSDTWIOtOiJVgF6Kob1AfgTRymPWk4AwgeGsc2-PxkUVHyoWRlXog/w1200-h630-p-k-no-nu/Alaric+3.jpg',
    respostaCerta: 1
  },
  {
    id: 5,
    pergunta: 'Qual objeto é essencial para os vampiros andarem ao sol em Mystic Falls?',
    imagem: 'https://static.wikia.nocookie.net/thevampirediarieswikibroficial/images/6/6f/TVD_-_2.17_-_Know_Thy_Enemy.avi_snapshot_31.34_-2011.05.12_15.09.07-.jpg/revision/latest?cb=20170303235609&path-prefix=pt-br',
    opcoes: ['Capa mágica', 'Anel com lapis-lazúli', 'Poção de bruxa', 'Amuleto de prata'],
    respostaCerta: 1
  },
  {
    id: 6,
    pergunta: 'Quem transforma Damon e Stefan em vampiros?',
    imagem: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExIVFhUXFxcXGBUXFRcVFxgVFRcWFxUVFxUYHSggGBolGxcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAAECBAUGBwj/xABBEAABBAAEAwYDBgQEBAcAAAABAAIDEQQSITEFQVEGEyJhcYEykaEHFEKxwfAjUnLRYoKSoiQzU+EVJVRzssLx/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAJBEAAgICAgEEAwEAAAAAAAAAAAECESExAxJBIjJCURNhcQT/2gAMAwEAAhEDEQA/APJOHN1XQ4HA3bj+Ss8C7IyPYZHAjpoul4Xw7LDZBK458qejr4eJ0rOF4pw+vEAsugvQOL4ZuXpouBx7adpsr45dkRyx6sm/D3qCq87D0RYX3zRnREjQqk6M2jIljpQCvSN0oqm5tFapmbQgnKVJkDJwOpwXTQ1QK5zCYR0h0rQE2TQ03APM+S2ofAwuBzNG7tgNar1vZRNWacdotyNvUfvzVXGjQKxh8fEaAdqdgRSr8Qu1nFZNJO0TwQ5qy4dVDhoRJTd0lLY4rAJo0QOastIDVWB1VRFNhIyiGQckztkooQVI6sDikGEao2JbShh91a0Q8SLRYAgYoDkUSdpVeZimKyaSfpAAaq2G6IIgNWrAbQVSJh+0OwLPxnxUr2almzOtyICm7LeDeKRu98kDCMoImimWy4YRSxgUsEmxhClg9Fp4MvkF3TUjuAI0ULGyg0SKsjhaSjJGbOiSZFn05xFkcULmhnLkvPIMU7u3BsZIs1qvV+LPbkdoNlwUcjRG6wNzzXE1To6+N2rODxeGe86ggLFxXCwu7xkrK0A+a53ENG+g91tGVETgmcVPh+7dXJQc4jY6Lf4hhw5YM0WU+S3i7OVrqxgC5V5olbgZrYKNLHfJPtQnTMcGkSLDue4NbqSaCLiIfJanYtzRiDmF/wAJ9agGzQcRfPKXV6qm8WJLNF/EMdgo2NNGpC5tcxlbqT5m9P7LFlMuV5EZyO5n8Lbuh5bfJdLxSJ2LETA052kMYyxQaSK066WfIKfa2PuGNhe4AhuXTdwHNYqZ0/jtP6Oe7OwPe9gbGTTsxfRdVtIykDldFWeIN1DhVEke7d9PcfVX+yGNZG+El7K7ynlzsoA5H99Fpdvo4hIHRFpbI4y+E2PEA123m36quz7aJ6JQuzCwh0RJOaHhtkVjMxoKW8hFYIZtFWG60MVDkFLOzaqlomVFvvKCnE0EWgubYUGSlpUmgsUgxHVGxTgUBhVrRk/cXg3qsjGY4B1NF0dzta0cTIchs1osPDYIvc1rdS4gDrZNUiCW2Od6RB2Mfe/X256K5DinEMJuhofS/wD9VvivB2QeFzw2Qalp38gAEXsY+Izd1O4NjeCC8kAN0NGzsqbTV0Lq1KmyVAixqsvEfEt/FYMwOLCQQLAcPhcBs5vkQQfdYeKAzpQHMuwDQIk2nJCi2CI5ocFD2X4M7FnVEwYsFQxg1Swj6Wngx8ljNWv0SbJetKczbQ2gDdSXoryg2aKSnK4WUkUTZ6nh+2sksJcY9SOZQcFxLPESQ3XzWFg+JRfd6AbmUuGyNDDZC5HHJ2QkkkaE8wDTssbESEjkrM046hU3zX0+StIzk7GjquSzsZADqr2e9L+ijIOX6K06IeUYD462RWOVuWLXQKs+MXrotdmLVCcLGoT8G8GJicNPFVdbBAb7mhfmo95XNEa66I3GxHI9Usji1aZ6L9n+EiM5cTYbK71zZSBodQKzc/ys8Z9pYIxUjSc3isHXQDkOgXb9gZ2ve+R2jmsjYW0KdmD3Mk/qzB/z9Fn9qsJG4Syjxlv1cf0WUZUzsnGMrrRyvCuEQviihDz3mIaDJzyW4d06vIitxo8o/b/AjCTYeJopvcA67lxe8OPpoFX7MTy/fYgzISD8Nuy7OBGYDTRzgOXiR/texefiFf8AThjZ6HxPI/3raNuWTDkaUMGZhpAQrDXVssbhuIo0Stdx0UyVMiLtE5JLbqqY3VuvCqjd046CW0Ge/KnDbFqMrbRowpKKkyiw0jYw0hNNq7wR8iWIdbddrF+i2OwPD3fe4TKwta4OLL5uAzX+dLHmFA8/+y7zsDxGKQS5AQW0SHVmZ4GsYGV+HK0i/oov0m8Ipy3k5bt7hiZXZjbi8kkbAbAfJGl4FAcsEbxmYGSOdoS+T8cRPJ2XK4CyBlcuj49hYwx73jM6tB5kaLmOxeIeeJMa0g5mlpac1EDxV62N657Ig28F8iin/TV7fw5Zmt1oxxvGas2rQw3QrXIFw048S9D+1B4+/OrZsUYrpoXV/uXnuI+JXA5uQvQt0CWHaRdpMNBTHVS2WkUOIDVNg1LiDrKjhgtPBl8i2/RCw/iJKK9pUcPpagvbKEsWpSU5neIpKjJxIR4ksNAaLoosR4RfRcww2tPCYuzRKU4lQkbIlG/6J4ZP3SptmCcSk9fksqNbLbna7/RJ0nRVJ3nzSixHknRLyWQFjccxIHhG605pyLoLmZg+SSmtLnE0GtBcT6AalaQWTKVpFyF7e7t26qjFa6aK7N2fljH8dzYdLyOOaQiuTG3R8nELe7J8BwuR2KxOZ0bCAGk5Q99F2UgA3sNL96WromMWbP2aSSuGIzA5RC17b/wyeHTkDb6vejSN2i4g6BhkygxSD4DrRO49L2WR2K7XiPGTumoMxIyk7BmW+7FcmgEt+Sn2yxwYRDoae1wB2yGnD9Vyzj6zt4pVCrH7McDxccn34MYGMa9+VzqJDW5i2gN+Wq4njGNkmnkllsPe8ucDyvZuvQUPZemYntfBHhZAXZi+OSNjG7kvBaXH+Vtnc9FwsXCzPhO+aRnheI32d2P/AOWfUOtvofJa8VvLMeZLSMWN9LX4fjm7FZM8DmGnAg+fP0Ox9kO1o42c6k0dS6VpCqtl1WdhMZWhV5ptR1o0cuxdMgKdrmqlmT975KeqK7MJi3AnRNhXi9Qhl3kkDXJOsUTbuy697en0Wv2ChHfyNa8gd09waNC4At0vnVmvVcvLisotWOzvaAYfFRSuByah9b5XtIv2sGvJHTGC48lSTZ2faPPh4RKJHOa+6DwNgsbsRGW4huOlnjga2wM1eKxR3IAWp9oeOZLhWd24OaKog6EEgg/VeYuPU/vyU8cMGnNyUzsOL8RM0skrnF+dzqfVZmAlrDXLwhuixX6nZUcTxFxAa3whug+ihHj3c6P0W3StHM53s6BkgrZRdIspnE+o+qn98O4BPpqp6MruWMVqbpRhNKrJjSfwn5FBGMPROhOWTWMxQTKVQ+/HomE7js0+wKOody046pKpcn8rv9JSToXYi1orfVTjJGyAERjyE6JTL0OJ1q1o4bEg6c1hWAbCKyXnzUSjZcZUdDyVc3dUoYGcObqijdZVRrdjy3lqr6dVt8GMcDcrNDp3kmoc97nOYAXb921zHU0bgWd6Q+zPDjNK91eGGKSc+sbCYx7yZPkVjy8RYYYMvKJscnXNmkLHelueD6rSGhSqwOLlL3Fz9u+MLx0u6PlVX7LoJ+Md7gxgYYC3um5JbIa5z68clebxteyyMdhM7ccANu4mHq5uZ/0cUhK57BPGf40YySAbyMbVO/qC0It2c3RBoivXRExGIc/LmdeVoaL/AJRsPZdBxAR4jDPmYBnYWvJoXR8L/b4TXIg9VzTtN/3eoQDwRdS9G7D4CDJLh3SHvZYA9wvpZaWjkW2N9dV5wBZWxBixEJCC5spyhpaTnsHw2R8NVdDXZAk/ILDYn42hofGP+oK3NDQbEnatRqj47grTEZ8PbmNJD2H42V+MfzMI1vcc+qq8Xw5hbHE74i3vZP6nk5QfRoH+orouEO+7zRsB1a+CEjcOfI8GdpHMEd40+QHkgW9nGELR4biq0cl2l4d93xU0PJjzl/od4mf7SFm2k1ZKdM6lmU6obwLtZGCxeU0dlqd407LJxo2UkyVdFOhzQmuQ8W+yB81UYOQpTSK2Oew6C9ASTyof91n43DuaW5uYBvqCAf1r2VzEjOKbppXrWwQzL3keR3xs28wNx61+S36pYMW7KjJXAFtmjyvT5JsTIXUTWgA0FaBQaUz3WpodkU4CQantMQxRoZSKIP780BOHckAe0/ZrjcPjIHxTMZ94jGtgZpGcn1zI2J9DzXmHaLDNZiZmtFAPIAVDh2MfG9skbyyRhtrx+R8iNPorOPxRle+Rwpzjbh0J39liuLrNyWmX2tUbf2c8LZPiDnFhoH1XsHDeAQAu/ht26Lzb7G4A7ESWeQ/VezYTCAF2qx5ZesqKwBg4Dh8o/ht+SSDLIQSM4FJLOyqPmFqlaiUy9A5wrSpN0KEFIKWNMu4Oaneq02lYTTra1MCHPc1jBbnENaP8TjQ+qiSNYvwepdgcH3eBnlO8+Zo/9tgLfq5zvkvIp2hhyXRBfG6+gdbXfX/avcsYwRYdkTD4WtY1h5mgNfU7+68R41HmxLgBq5wFf4ia/UKoqip4Vnos2A7sPfVh8TA71awM/RcVGx0JOX+ax+oXp08BODkFfDlaDuXatH5BeZdoZg15aEBIDJi2te57Nngtkj2zAinFvn5LNjhHdF7yaFtYObnc/wDKPzPqgPNppZCas/CMo8gP+5J90zFsZjyDY3Vrh+IDHZqt3K+RP4vVU04TEmbE8odjA93wtLHG9fDEwE//ABPzVvhEhfPgy42TM6Zx/meHAi/ZoHuVgCTR3UjL8zr9LRYcY5htvJpa09AfiI8ySfmgdnUfarGPvcco2lgYSermlzT9A1ceGldH2rx7ZosHRssjcx3sWkfQrCY7cICWwARoZy0hFwOGLjtojT8NO4KhtaBJ7RZlxzRGSN9vc81nRzEPq9Dp78kDEMIAB31+X7tDLtQfQ+6uOAk7NGWMg6c/zUJm34tnLSaA9mYLLxJ6H96rRkFV5021tRa1TkA0r3SKkZF5Q1N6gkMSSSfKd0AMCrccl779eo6FVFIOQB6f9jeFd3sp9PyXrj3vja929DQL5/7B9pX4PEB9Zoz4Xt/wnZw8x/degy9sZ8TJWHiLmNd4vMfulx80H2s0jJVRpf8AgWKluTvMuYk1W2uiSvxdq5ABeGk+SSy6srB85JJJUvRMBwpgodIzNkmNEVsdlZiMXAMjpAXgFjQS5wNghta3ROvJZJC7rsDgohBLiQ9v3iN/4mOeGwloG3w245hrrQO26TKisnQ9ouMugiY2ay0loa7Z4oXlkaB8TbAzgakajr5jx3EA4h0jCCCWuaRtoBr8wdFd47i3Oc6QSNcXON0wNNHk4Vt03KwHoRU5eD6EjhLsNkBoyklzujAKNeZ2914j2klDsQ8DZpyj2XtOG4iI8O9z9BDAXjodNAfPMQvGuD8OLz3j9iefO7s/NIqecFHCxbkjlYP6KvE23AHmQFqcVlAc2IaBuhrmSBv11WS9tFMyeBgU6eQ6mtkyZIzikExT2gArDZAP7tX3wtAsLMaVcw0zaObdTIYXAS5SVbjkA1cdFmxOBPRFcfKwoayCvwVuKy5pDWwoD5D9SVUVnENBGa9elHbreyrALVaAu4ORxaW8uX9kJ5KvwR5MtHdwN+Z0VXEMIc4dCR9VSdg1QE7JgpO3UeRQIG5RSSSGOFJz9+n9lBJAGri+ByNw8WKa0uieCHOA0ZI17mlrul0COtrKXrn2fy/+S4nwseWCemP1YQGNdTh03XkiiErbX0NqixgD4xr6+nNe1/ZFio3QPFDM12/VrtWn6H6LxHDRZjS9c+xqCxiZPw2yNv8AkDi4/wC4Jc3sCOz0oTM8vkElWEbf2Ulw9jY+XlpcDA7zUclmK9wmdrHW7ou/k9rMoe5DcWrvDSAxT4hKHPJGyGxEcRQS9zCLveyuFb/4TiZHAk9/TdTQyxss1sTrWu3zXAAr1H/k8BgFayd5IfPNK6j/AKQ1RyPBrwq5HmL2o/CsEJZWMLg3M4CzzP8AL5WhsFrV7LRB2MhFaZ83+kE/oFaZMoqz0vtHD/wpaDQe9rCBzawZq9Ly/Jcf4clMGwP7+a7XtXMPujANyXi/O7+dUFxHBpbNedV5HdBozkeIyZpXOHM/WtfqFCxWv4vpWxROLQd3NI3o416HUfmqtqjnexUpd2dkWCDMHVuBf91rMha6Iy1sBm9f2ErGo2YrJS0OAA8QAJIsgWDoeWwQlIm7J3SATIGCtNhBbaePC20OvnSQIHNS39FVWxhDporGHJqiFVkm6bK7hCMtKXopFSZlN9z7dFTadf7LV7sOJaf3Synto+60WiWsmi1/hbp+IWaq9Runx/xk1V6+1bokuuGaej/0QuIYjMaA0G3WjrqqqiSoxtnevM3p8lCY8vVEfogPKAIpJJJDEknpGwzW5hm6oA7JuOOG4N3QNSYmZ7TyPdNDe8P0a3/MVxDlrcTxhnytBAZE3K0eptzvUlZboyNa0UxSQ3ZawsTqIa0lxoCv8Rr9V7JwbhjsBBHCHeKi555F7tXew29l5JwLHCOUP3y04DqWkOA+YXT43t3PI6zHXusv9EZSSSF4O7GMd/MnXnjO1rwPhP0SXH+GZfZnEJ0kl6ZAkQFQCmEmIclendvpu5wOBhH/AKeMEerGkn52vMQCSAOZA+ei7/7XJf8Aio4hsyJgrzyhZz2kdHC6TZxYNNvmdB+pXSfZ3Bmne8/gYAPV5r/6/VctM+9Omi637NT45/6Wfm5UT2uR2Had94QOGpa8n5gBclwTCZnF5Ph3/v8AVdRxM5onsJ3r8xf0tYoIjYQBpRP00+qC2cX2gxXeTu0oNJaNNaHUrNU5nkuJPMlQVHO9l3hE2SVpOx0PoVo8Rd3TZGDZ2nz1CwgVdx2J7xrSdxoUiovBRyqZClGRVFKtPT9UEosCT+ER5hVFIP0IUQkkOTskyr1RHPr4SoudagECui7HONDzCvM7Pulg+9ZxRcW5QLIIvfpryWWxunmuo7DTGpsO+8rwHsHWRule7Sf9KmUqjg040pSplTCxwHCEAlsscoD2ucMpY5rqe3TTxCvcLExc4cQRvQHtX97Wv204QYXh4BDH7HlmA1HsudaaGyuGVYuVU6JyjTzQQLRG6lQNaq2ZjFqQPknzJi5IZEqTUwaiAJAje7KcNjmlAeajYDJK7kGNqh6kkD3Wjx3FCV9tblYNGjnXK/7ck2HcIMIInUHSPEr+oaARGw9dy6vRUvvFjQLnk23ZrOTS6oqYgButJRSghFlkDjqFDIE08ELQj7JJEgJIF2MJJJJdAiQUwoAqSQjW7KYQS43DRnZ0zL9A4E/QLb+07GZ+IzV+Gm+4ATfZPgu84lETtE18x/ytpv8Auc1Y/ajE58VK678btbu9dPks3mRvDEGR7OYPvJ22PC0sJ6W57Y478s7m+wK2OwJyzzAfDRB9nHKVzGHxLmEFpIotO5AJabbdb0V2XZgMEkkjQQ2UWBvlO7mX18VjqD5KyIbOimBJI0/fRYna52TD0DqSLPQcwPVbLtOS4rtXi3yyFoPgbsBzrQk/vkkjSTwc4UykVBUc46e0ySACCM5c1aZst+dXXySj3rqF0B4eIuHOfJQfJLGY2n4soBzED0KwhMKqtUmOqBNbakYyNCpRHRx8v1CI12bnqkDAPbSlDHaT2kHdSrogQUYc7tKv4Gd4ILTTmkEHoQquEbd66BBfMQd1DV4GnR6jxmGLGcNGUgPADmjNWWSNri5uvUX7UV5K0c1p4PizmhzCA5jgQWnUbHK7ycDqCs9sJyB1adfcj8wr400qZfJNSpkHvQVJ5SDFZAytQYJxYZD4WCwCfxO/lb1P0CFGwXRO/NRLiQASaGwvQX0HJAJoLHFe2pP73V0YYMiMuYF4IyitBe513I/RZ0LjY1XQRtHdkaHxO22st0r3IU0PtRUa7OdT6kqIlbmIBTyBtHWlVjhuy0rJJMnsTEhJ/VEZMdUGaMj9UFjtCqqwQ7pfNJCKSugoCkkkqGOFMKACdJiO1+zfFZTi2s0lfAQx3RgJMgHmT3a41x1WnwLj0uFJ7s6OLS4dcmYAenjd+wFnyvBNi9daPXmprJr2TgkQWhhOJOgksWR+Jt6OoUPQ0VRwrS57QNddvTWvomxLtTXVUZHcYTtNC8DM7LrVO3qjvyNdfJZnGMOLL2OBDgRvoc3MHrqFyqYIo07lidoDq9PyCGhpWiiCdqTN0JWcHvqmIt4+cyOtxJoAC+QoaDoFSyouJf43fvkEMu1tSwQSIaO/p/LVDjKORlj83H5Ab/Mn6FV0ipE3kKAcoqRCZJNsh2TTUoNTyEckARVuXFfwWsG96/0g2PqfoqZK0sICYgKaRmduB5JoDOjZZTrSGA3Njba9lmsdrSYEUyeTeknCkAKN2trb4aSQXenpZLQfoAsRi3MI6ozXS/chDBlCdmn1UcOaCMyBwJvdVpHHZZL6M0TfJpSrObqkUlSVF0LRJMkmMEkkkqGIFOnSQIZOkkgC1wxv8QeVn6KGKrMaFJJJgV3JkkkhjpkkkAJHwp11SSQAp9XH1Tsk0rT15pJJMSZKR3nfqhEpJJIbEE5cmSVUIjmTpJIAZaGFkqImgacasXqQ1OkgCm7EOO5/RBpJJABYY7OvIJP1SSQANu628tQZgdRevsQkkgChhnncklDmYbTpKPIvJFzK33Q+SSSaGRSSSVAf/9k=',
    opcoes: ['Bonnie', 'Rose', 'Katherine Pierce', 'Lexi'],
    respostaCerta: 2
  },
  {
    id: 7,
    pergunta: 'Bonnie Bennett pertence a qual linhagem sobrenatural?',
    imagem: 'https://static.wikia.nocookie.net/legaciesbr/images/2/25/816-004_Elena-Bonnie.png/revision/latest?cb=20200119005723&path-prefix=pt-br',
    opcoes: ['Vampira', 'Bruxa', 'Lobisomem', 'Híbrida'],
    respostaCerta: 1
  },
  {
    id: 8,
    pergunta: 'Qual híbrido original é conhecido por transformar lobisomens em híbridos?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6GsNvaXsJvXIYQB9wXnPKVDYHLsiecDYJtA&s',
    opcoes: ['Elijah', 'Kol', 'Klaus', 'Finn'],
    respostaCerta: 2
  },
  {
    id: 9,
    pergunta: 'O que a família Lockwood se transforma sob a luz da lua cheia?',
    imagem: 'https://i.pinimg.com/236x/6f/1c/4b/6f1c4b3d1490684a7db93bdc0991bb68.jpg',
    opcoes: ['Vampiros', 'Lobisomens', 'Bruxos', 'Fantasmas'],
    respostaCerta: 1
  },
  {
    id: 10,
    pergunta: 'Quem é o irmão mais velho e original da família Mikaelson?',
    imagem: 'https://pt.quizur.com/_image?href=https://img.quizur.com/f/img5cc5eef342e121.10571039.jpg?lastEdited=1556475637&w=1024&h=1024&f=webp',
    opcoes: ['Stefan', 'Damon', 'Elijah', 'Klaus'],
    respostaCerta: 3
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [respostaSelecionada, setRespostaSelecionada] = useState(null);
  const [bloqueado, setBloqueado] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
    setRespostaSelecionada(null);
    setBloqueado(false);
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (bloqueado) return;

    setBloqueado(true);
    setRespostaSelecionada(indiceClicado);

    setTimeout(() => {
      setCarregando(true);
      setRespostaSelecionada(null);
      setBloqueado(false);

      const pergunta = QUIZ[perguntaAtual];
      if (indiceClicado === pergunta.respostaCerta) {
        setPontuacao(p => p + 1);
      }

      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(p => p + 1);
        } else {
          setTelaAtual('resultado');
        }
        setCarregando(false);
      }, 1000);
    }, 1000);
  }

  function corDoBotao(index) {
    if (respostaSelecionada === null) return styles.botaoOpcao;
    if (index !== respostaSelecionada) return styles.botaoOpcao;
    return index === QUIZ[perguntaAtual].respostaCerta
      ? styles.botaoCorreto
      : styles.botaoErrado;
  }

  // ==========================================
  // TELA INICIAL
  // ==========================================
  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🦇</Text>
        <Text style={styles.tituloPrincipal}>Diário de um Vampiro</Text>
        <Text style={styles.subtituloInicio}>Você conhece bem Mystic Falls?{'\n'}Teste seus conhecimentos!</Text>
        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>🩸  INICIAR JOGO</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ==========================================
  // TELA DE RESULTADO
  // ==========================================
  if (telaAtual === 'resultado') {
    const nota = pontuacao / QUIZ.length;
    const emoji = nota >= 0.8 ? '🧛' : nota >= 0.5 ? '🦇' : '🌕';
    const mensagem = nota >= 0.8 ? 'Você é um original!' : nota >= 0.5 ? 'Bom conhecedor de Mystic Falls!' : 'Precisa rever os episódios!';
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>{emoji}</Text>
        <Text style={styles.titulo}>{mensagem}</Text>
        <Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ==========================================
  // TELA DE CARREGAMENTO
  // ==========================================
  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#b91c1c" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  // ==========================================
  // TELA DO QUIZ
  // ==========================================
  const pergunta = QUIZ[perguntaAtual];

  return (
    <ScrollView style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>🦇 {perguntaAtual + 1} / {QUIZ.length}</Text>
        <Text style={styles.pontos}>🩸 {pontuacao} pts</Text>
      </View>

      <View style={styles.cartaoPergunta}>
        <Image source={{ uri: pergunta.imagem }} style={styles.imagemPergunta} />
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => (
          <TouchableOpacity
            key={index}
            style={corDoBotao(index)}
            onPress={() => responder(index)}
            activeOpacity={0.7}
            disabled={bloqueado}
          >
            <Text style={styles.textoOpcao}>{opcao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#120505', padding: 20, paddingTop: 60 },
  telaCentrada: { flex: 1, backgroundColor: '#120505', justifyContent: 'center', alignItems: 'center', padding: 20 },
  iconeGrande: { fontSize: 80, marginBottom: 20 },
  tituloPrincipal: { fontSize: 32, fontWeight: '900', color: '#fef2f2', marginBottom: 10, textAlign: 'center' },
  subtituloInicio: { fontSize: 16, color: '#fca5a5', marginBottom: 50, textAlign: 'center', lineHeight: 24 },
  botaoIniciar: { backgroundColor: '#7f1d1d', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, alignItems: 'center', borderWidth: 1, borderColor: '#b91c1c', elevation: 8 },
  textoBotaoIniciar: { color: '#fef2f2', fontSize: 20, fontWeight: '900', letterSpacing: 1 },
  cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20, paddingHorizontal: 5 },
  progresso: { fontSize: 16, fontWeight: '700', color: '#fca5a5' },
  pontos: { fontSize: 16, fontWeight: '800', color: '#dc2626' },
  cartaoPergunta: { backgroundColor: '#1c0a0a', borderRadius: 20, marginBottom: 20, overflow: 'hidden', borderWidth: 1, borderColor: '#450a0a' },
  imagemPergunta: { width: '100%', height: 160, resizeMode: 'cover' },
  textoPergunta: { fontSize: 18, fontWeight: '800', color: '#fef2f2', textAlign: 'center', lineHeight: 26, padding: 20 },
  areaOpcoes: { flex: 1 },
  botaoOpcao: { backgroundColor: '#1c0a0a', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#450a0a' },
  botaoCorreto: { backgroundColor: '#14532d', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#22c55e' },
  botaoErrado: { backgroundColor: '#450a0a', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#ef4444' },
  textoOpcao: { fontSize: 16, color: '#fef2f2', fontWeight: '600', textAlign: 'center' },
  titulo: { fontSize: 28, fontWeight: '900', color: '#fef2f2', marginBottom: 10, textAlign: 'center' },
  subtitulo: { fontSize: 18, color: '#fca5a5', marginBottom: 40, textAlign: 'center' },
  botaoAcao: { backgroundColor: '#7f1d1d', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center', borderWidth: 1, borderColor: '#b91c1c' },
  textoBotaoAcao: { color: '#fef2f2', fontSize: 18, fontWeight: '800' },
  textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#dc2626' }
});
